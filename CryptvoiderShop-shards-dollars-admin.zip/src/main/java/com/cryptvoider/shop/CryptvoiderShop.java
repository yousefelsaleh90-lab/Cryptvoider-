package com.cryptvoider.shop;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.*;

import java.util.*;

public final class CryptvoiderShop extends JavaPlugin implements Listener {
    private final Map<UUID, Long> shards = new HashMap<>();
    private final Map<UUID, Long> dollars = new HashMap<>();
    private final Map<Material, Price> prices = new HashMap<>();
    private final Map<UUID, String> search = new HashMap<>();
    private final Map<UUID, Location> homes = new HashMap<>();
    private final Map<UUID, Location> lastLocations = new HashMap<>();
    private final Map<UUID, UUID> tpaRequests = new HashMap<>();
    private final Map<UUID, Boolean> tpaHereRequests = new HashMap<>();
    private final Map<UUID, TradeSession> trades = new HashMap<>();
    private final Map<UUID, Set<UUID>> friends = new HashMap<>();
    private final List<MarketListing> marketListings = new ArrayList<>();
    private record MarketListing(UUID seller, String sellerName, ItemStack item, long price) {}

    private record Price(long buy, long sell, String category) {}

    @Override public void onEnable() {
        saveDefaultConfig();
        loadPrices();
        loadBalances();
        loadMarket();
        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("shop")).setExecutor(new ShopCommand(this));
        Objects.requireNonNull(getCommand("shards")).setExecutor(new ShardsCommand(this));
        register("rtp", new UtilityCommand(this));
        register("sethome", new UtilityCommand(this));
        register("home", new UtilityCommand(this));
        register("spawn", new UtilityCommand(this));
        register("back", new UtilityCommand(this));
        register("tpa", new UtilityCommand(this));
        register("tpahere", new UtilityCommand(this));
        register("tpaccept", new UtilityCommand(this));
        register("tpdeny", new UtilityCommand(this));
        register("msg", new UtilityCommand(this));
        register("tell", new UtilityCommand(this));
        register("bal", new UtilityCommand(this));
        register("balance", new UtilityCommand(this));
        register("pay", new UtilityCommand(this));
        register("friends", new UtilityCommand(this));
        register("kit", new UtilityCommand(this));
        register("trade", new TradeCommand(this));
        register("sell", new MarketCommand(this));
        register("market", new MarketCommand(this));
        register("money", new UtilityCommand(this));
        register("cash", new UtilityCommand(this));

        // Give each online player 1 virtual Shard every 5 minutes.
        // 20 ticks = 1 second, so 6000 ticks = 5 minutes.
        getServer().getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                give(p.getUniqueId(), 1);
                p.sendMessage("§d+1 Shard §7for playing! §fBalance: §d" + balance(p.getUniqueId()));
            }
        }, 6000L, 6000L);
        getServer().getScheduler().runTaskTimer(this, () -> Bukkit.getOnlinePlayers().forEach(p -> {
            updateMoneyBoard(p);
            updateAdminTag(p);
        }), 20L, 40L);
    }

    void loadPrices() {
        prices.clear();
        ConfigurationSection s = getConfig().getConfigurationSection("items");
        if (s == null) return;
        for (String key : s.getKeys(false)) {
            Material m = Material.matchMaterial(key);
            if (m != null) prices.put(m, new Price(
                s.getLong(key + ".buy", 0),
                s.getLong(key + ".sell", 0),
                s.getString(key + ".category", "OTHER")));
        }
    }

    long balance(UUID u) { return shards.getOrDefault(u, (long)getConfig().getInt("players." + u + ".balance", getConfig().getInt("settings.starting-shards", 0))); }
    long cashBalance(UUID u) { return dollars.getOrDefault(u, getConfig().getLong("players." + u + ".cash", 0L)); }
    void setCashBalance(UUID u, long v) { long amount=Math.max(0,v); dollars.put(u, amount); getConfig().set("players." + u + ".cash", amount); saveConfig(); }
    void giveCash(UUID u, long v) { setCashBalance(u, cashBalance(u)+Math.max(0,v)); }
    void setBalance(UUID u, long v) { shards.put(u, Math.max(0, v)); getConfig().set("players." + u + ".balance", Math.max(0, v)); saveConfig(); }
    void loadBalances() { ConfigurationSection section=getConfig().getConfigurationSection("players"); if(section!=null) for(String key:section.getKeys(false)) try { shards.put(UUID.fromString(key), section.getLong(key+".balance",0)); dollars.put(UUID.fromString(key), section.getLong(key+".cash",0)); } catch(IllegalArgumentException ignored) {} }
    void updateMoneyBoard(Player p) {
        Scoreboard board=p.getScoreboard();
        Objective objective=board.getObjective("moneyboard");
        if(objective==null) { board=Bukkit.getScoreboardManager().getNewScoreboard(); objective=board.registerNewObjective("moneyboard", Criteria.DUMMY, "§d§lCRYPTVOIDER"); objective.setDisplaySlot(DisplaySlot.SIDEBAR); p.setScoreboard(board); }
        for(String entry:new HashSet<>(board.getEntries())) board.resetScores(entry);
        objective.getScore("§d◆ §f"+balance(p.getUniqueId())+" Shards").setScore(2);
        objective.getScore("§a$ §f"+cashBalance(p.getUniqueId())+" Money").setScore(1);
    }
    void updateAdminTag(Player p) {
        String shown = p.isOp() ? "§c[Admin] §f" + p.getName() : p.getName();
        p.setPlayerListName(shown);
        p.setDisplayName(shown);
    }

    void saveMarket() { getConfig().set("market", marketListings); saveConfig(); }
    void loadMarket() { marketListings.clear(); List<?> raw=getConfig().getList("market", List.of()); for(Object o:raw) if(o instanceof ConfigurationSection) {} else if(o instanceof Map<?,?> map) { try { UUID seller=UUID.fromString(String.valueOf(map.get("seller"))); Object item=map.get("item"); long price=Long.parseLong(String.valueOf(map.get("price"))); if(item instanceof ItemStack stack && price>0) marketListings.add(new MarketListing(seller, String.valueOf(map.get("name")), stack, price)); } catch(Exception ignored) {} } }
    void saveMarketListings() { List<Map<String,Object>> data=new ArrayList<>(); for(MarketListing l:marketListings){Map<String,Object> row=new HashMap<>(); row.put("seller",l.seller.toString()); row.put("name",l.sellerName); row.put("item",l.item); row.put("price",l.price); data.add(row);} getConfig().set("market",data); saveConfig(); }
    void openMarket(Player p) { Inventory inv=Bukkit.createInventory(null,54,"§8Cryptvoider Market"); for(int i=0;i<Math.min(45,marketListings.size());i++){MarketListing l=marketListings.get(i); ItemStack shown=l.item.clone(); ItemMeta meta=shown.getItemMeta(); List<String> lore=meta.hasLore()?new ArrayList<>(meta.getLore()):new ArrayList<>(); lore.add("§7Seller: §f"+l.sellerName); lore.add("§aPrice: §f"+l.price+" Shards"); lore.add("§eClick to buy"); meta.setLore(lore); shown.setItemMeta(meta); inv.setItem(i,shown);} p.openInventory(inv); }

    boolean take(UUID u, long v) { if (balance(u) < v) return false; setBalance(u, balance(u)-v); return true; }
    void give(UUID u, long v) { setBalance(u, balance(u)+Math.max(0,v)); }

    void openShop(Player p, String query) {
        search.put(p.getUniqueId(), query == null ? "" : query.toLowerCase(Locale.ROOT));
        String q = search.get(p.getUniqueId());
        Inventory inv = Bukkit.createInventory(null, 54, "§8Cryptvoider Shop §7" + (q.isEmpty() ? "" : "• " + q));
        int slot = 0;
        for (var e : prices.entrySet()) {
            if (!q.isEmpty() && !e.getKey().name().toLowerCase(Locale.ROOT).contains(q)) continue;
            if (slot >= 45) break;
            inv.setItem(slot++, item(e.getKey(), e.getValue()));
        }
        inv.setItem(49, button(Material.COMPASS, "§bSearch", "§7Type /shop search <name>"));
        inv.setItem(53, button(Material.DIAMOND, "§dShards: §f" + balance(p.getUniqueId()), "§7Virtual currency"));
        p.openInventory(inv);
    }

    ItemStack item(Material m, Price pr) {
        ItemStack x = new ItemStack(m);
        ItemMeta meta = x.getItemMeta();
        meta.setDisplayName("§f" + pretty(m));
        meta.setLore(List.of("§aBuy: §f" + pr.buy + " Shards", "§cSell: §f" + pr.sell + " Shards", "§7Left-click: buy 1", "§7Right-click: sell 1", "§7Shift-click: buy/sell 16"));
        x.setItemMeta(meta); return x;
    }

    ItemStack button(Material m, String name, String lore) {
        ItemStack x = new ItemStack(m); ItemMeta meta=x.getItemMeta();
        meta.setDisplayName(name); meta.setLore(List.of(lore)); x.setItemMeta(meta); return x;
    }

    static String pretty(Material m) {
        String[] a=m.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder b=new StringBuilder();
        for(String s:a) b.append(Character.toUpperCase(s.charAt(0))).append(s.substring(1)).append(' ');
        return b.toString().trim();
    }

    @EventHandler public void click(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getView().getTitle().equals("§8Cryptvoider Market")) {
            e.setCancelled(true); int slot=e.getRawSlot(); if(slot<0 || slot>=45 || slot>=marketListings.size()) return;
            MarketListing listing=marketListings.get(slot); if(listing.seller.equals(p.getUniqueId())) { p.sendMessage("§cYou cannot buy your own listing."); return; }
            if(!take(p.getUniqueId(),listing.price)){p.sendMessage("§cYou need "+listing.price+" Shards.");return;}
            marketListings.remove(slot); give(listing.seller,listing.price); saveMarketListings();
            Map<Integer,ItemStack> leftover=p.getInventory().addItem(listing.item.clone()); leftover.values().forEach(x->p.getWorld().dropItemNaturally(p.getLocation(),x));
            p.sendMessage("§aBought item for §f"+listing.price+" Shards§a."); Player seller=Bukkit.getPlayer(listing.seller); if(seller!=null)seller.sendMessage("§aYour market listing sold! You received §f"+listing.price+" Shards§a."); openMarket(p); return;
        }
        if (!e.getView().getTitle().startsWith("§8Cryptvoider Shop")) return;
        e.setCancelled(true);
        if (e.getRawSlot() < 0 || e.getRawSlot() >= e.getView().getTopInventory().getSize()) return;
        ItemStack clicked=e.getCurrentItem();
        if (clicked==null || clicked.getType().isAir()) return;
        Material m=clicked.getType();
        Price pr=prices.get(m);
        if (pr==null) return;
        int amount=e.isShiftClick()?16:1;
        if (e.isLeftClick()) {
            long cost=pr.buy*amount;
            if (!take(p.getUniqueId(), cost)) { p.sendMessage("§cYou need §f"+cost+" §cShards."); return; }
            HashMap<Integer,ItemStack> left=p.getInventory().addItem(new ItemStack(m, amount));
            left.values().forEach(x->p.getWorld().dropItemNaturally(p.getLocation(),x));
            p.sendMessage("§aBought §f"+amount+"x "+pretty(m)+" §afor §f"+cost+" Shards§a.");
        } else if (e.isRightClick()) {
            int have=count(p,m);
            int sell=Math.min(amount,have);
            if(sell<=0){p.sendMessage("§cYou don't have that item.");return;}
            remove(p,m,sell); give(p.getUniqueId(), pr.sell*sell);
            p.sendMessage("§aSold §f"+sell+"x "+pretty(m)+" §afor §f"+(pr.sell*sell)+" Shards§a.");
        }
        openShop(p, search.getOrDefault(p.getUniqueId(),""));
    }

    int count(Player p, Material m){int n=0; for(ItemStack x:p.getInventory().getContents()) if(x!=null&&x.getType()==m)n+=x.getAmount(); return n;}
    void remove(Player p, Material m, int n){for(int i=0;i<p.getInventory().getSize()&&n>0;i++){ItemStack x=p.getInventory().getItem(i);if(x!=null&&x.getType()==m){int take=Math.min(n,x.getAmount());x.setAmount(x.getAmount()-take);n-=take;}}}

    @EventHandler public void close(InventoryCloseEvent e){ if(e.getPlayer() instanceof Player p) search.remove(p.getUniqueId()); }
    void plCleanup(UUID id) {
        tpaRequests.remove(id);
        tpaHereRequests.remove(id);
        search.remove(id);
    }

    static class ShopCommand implements CommandExecutor {
        final CryptvoiderShop pl; ShopCommand(CryptvoiderShop p){pl=p;}
        public boolean onCommand(CommandSender s, Command c, String l, String[] a){
            if(!(s instanceof Player p)){s.sendMessage("Players only.");return true;}
            if(a.length>=2 && a[0].equalsIgnoreCase("search")) {pl.openShop(p,String.join(" ",Arrays.copyOfRange(a,1,a.length)));return true;}
            pl.openShop(p,""); return true;
        }
    }


    void register(String name, CommandExecutor executor) {
        if (getCommand(name) != null) getCommand(name).setExecutor(executor);
    }

    Player findPlayer(String name) {
        return Bukkit.getPlayerExact(name);
    }

    void sendPrivate(Player from, Player to, String msg) {
        from.sendMessage("§7[§dYou §7-> §d" + to.getName() + "§7] §f" + msg);
        to.sendMessage("§7[§d" + from.getName() + " §7-> §dYou§7] §f" + msg);
    }

    void randomTeleport(Player p) {
        World w = p.getWorld();
        int radius = Math.max(100, getConfig().getInt("settings.rtp-radius", 5000));
        for (int i = 0; i < 12; i++) {
            int x = p.getLocation().getBlockX() + (int)(Math.random() * (radius * 2 + 1)) - radius;
            int z = p.getLocation().getBlockZ() + (int)(Math.random() * (radius * 2 + 1)) - radius;
            int y = w.getHighestBlockYAt(x, z) + 1;
            if (y <= w.getMinHeight() || y > w.getMaxHeight()) continue;
            Location loc = new Location(w, x + .5, y, z + .5);
            Material below = w.getBlockAt(x, y - 1, z).getType();
            if (below.isSolid() && !below.name().contains("LAVA")) {
                p.teleport(loc);
                p.sendMessage("§aRandomly teleported.");
                return;
            }
        }
        p.sendMessage("§cCould not find a safe random location. Try again.");
    }

    static class UtilityCommand implements CommandExecutor {
        final CryptvoiderShop pl;
        UtilityCommand(CryptvoiderShop p) { pl = p; }

        public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
            if (!(s instanceof Player p)) { s.sendMessage("§cPlayers only."); return true; }

            switch (label.toLowerCase(Locale.ROOT)) {
                case "money", "cash" -> {
                    if (a.length > 0 && a[0].equalsIgnoreCase("give")) {
                        if (!p.isOp()) { p.sendMessage("§cOnly operators can give money to themselves."); return true; }
                        if (a.length != 2) { p.sendMessage("§cUsage: /money give <amount>"); return true; }
                        long amount;
                        try { amount = Long.parseLong(a[1]); } catch (NumberFormatException ex) { p.sendMessage("§cAmount must be a whole number."); return true; }
                        if (amount <= 0) { p.sendMessage("§cAmount must be greater than 0."); return true; }
                        pl.giveCash(p.getUniqueId(), amount);
                        p.sendMessage("§aYou gave yourself §f$" + amount + "§a. Balance: §f$" + pl.cashBalance(p.getUniqueId()));
                        pl.updateMoneyBoard(p);
                        return true;
                    }
                    p.sendMessage("§aYou have $"+pl.cashBalance(p.getUniqueId())+"§a.");
                    pl.updateMoneyBoard(p);
                    return true;
                }
                case "rtp" -> {
                    pl.randomTeleport(p);
                    return true;
                }
                case "sethome" -> {
                    String name = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "home";
                    if (!name.matches("[a-z0-9_-]{1,16}")) {
                        p.sendMessage("§cInvalid home name.");
                        return true;
                    }
                    pl.homes.put(p.getUniqueId(), p.getLocation().clone());
                    p.sendMessage("§aHome §f" + name + " §aset.");
                    return true;
                }
                case "home" -> {
                    Location loc = pl.homes.get(p.getUniqueId());
                    if (loc == null) {
                        p.sendMessage("§cYou have no home set. Use /sethome.");
                        return true;
                    }
                    p.teleport(loc);
                    p.sendMessage("§aTeleported home.");
                    return true;
                }
                case "spawn" -> {
                    pl.lastLocations.put(p.getUniqueId(), p.getLocation().clone());
                    p.teleport(p.getWorld().getSpawnLocation());
                    p.sendMessage("§aTeleported to spawn. Use /back to return.");
                    return true;
                }
                case "back" -> {
                    Location last = pl.lastLocations.get(p.getUniqueId());
                    if (last == null) {
                        p.sendMessage("§cYou don't have a previous location to return to.");
                        return true;
                    }
                    pl.lastLocations.put(p.getUniqueId(), p.getLocation().clone());
                    p.teleport(last);
                    p.sendMessage("§aReturned to your previous location.");
                    return true;
                }
                case "tpa", "tpahere" -> {
                    if (a.length < 1) { p.sendMessage("§cUsage: /" + label + " <player>"); return true; }
                    Player target = pl.findPlayer(a[0]);
                    if (target == null) { p.sendMessage("§cPlayer not found."); return true; }
                    if (target == p) { p.sendMessage("§cYou cannot target yourself."); return true; }
                    pl.tpaRequests.put(target.getUniqueId(), p.getUniqueId());
                    pl.tpaHereRequests.put(target.getUniqueId(), label.equalsIgnoreCase("tpahere"));
                    if (label.equalsIgnoreCase("tpa")) {
                        target.sendMessage("§d" + p.getName() + " §fwants to teleport to you. §aUse /tpaccept §for §c/tpdeny§f.");
                    } else {
                        target.sendMessage("§d" + p.getName() + " §fwants you to teleport to them. §aUse /tpaccept §for §c/tpdeny§f.");
                    }
                    p.sendMessage("§aTeleport request sent to §f" + target.getName() + "§a.");
                    return true;
                }
                case "tpaccept" -> {
                    UUID requester = pl.tpaRequests.remove(p.getUniqueId());
                    boolean here = pl.tpaHereRequests.getOrDefault(p.getUniqueId(), false);
                    pl.tpaHereRequests.remove(p.getUniqueId());
                    if (requester == null) { p.sendMessage("§cYou have no pending teleport request."); return true; }
                    Player from = Bukkit.getPlayer(requester);
                    if (from == null) { p.sendMessage("§cThat player is no longer online."); return true; }
                    if (here) {
                        pl.lastLocations.put(p.getUniqueId(), p.getLocation().clone());
                        p.teleport(from.getLocation());
                        p.sendMessage("§aTeleport accepted.");
                        from.sendMessage("§aTeleport request accepted.");
                    } else {
                        pl.lastLocations.put(from.getUniqueId(), from.getLocation().clone());
                        from.teleport(p.getLocation());
                        from.sendMessage("§aTeleport accepted.");
                        p.sendMessage("§aTeleport request accepted.");
                    }
                    return true;
                }
                case "tpdeny" -> {
                    UUID requester = pl.tpaRequests.remove(p.getUniqueId());
                    tpaHereRequests.remove(p.getUniqueId());
                    if (requester == null) { p.sendMessage("§cYou have no pending teleport request."); return true; }
                    Player from = Bukkit.getPlayer(requester);
                    if (from != null) from.sendMessage("§cYour teleport request was denied.");
                    p.sendMessage("§cTeleport request denied.");
                    return true;
                }
                case "msg", "tell" -> {
                    if (a.length < 2) { p.sendMessage("§cUsage: /" + label + " <player> <message>"); return true; }
                    Player target = pl.findPlayer(a[0]);
                    if (target == null) { p.sendMessage("§cPlayer not found."); return true; }
                    pl.sendPrivate(p, target, String.join(" ", Arrays.copyOfRange(a, 1, a.length)));
                    return true;
                }
                case "bal", "balance" -> {
                    p.sendMessage("§dBalance: §f" + pl.balance(p.getUniqueId()) + " Shards");
                    return true;
                }
                case "pay" -> {
                    if (a.length < 2) { p.sendMessage("§cUsage: /pay <player> <amount>"); return true; }
                    Player target = pl.findPlayer(a[0]);
                    if (target == null) { p.sendMessage("§cPlayer not found."); return true; }
                    if (target == p) { p.sendMessage("§cYou cannot pay yourself."); return true; }
                    long amount;
                    try { amount = Long.parseLong(a[1]); } catch (Exception ex) {
                        p.sendMessage("§cInvalid amount."); return true;
                    }
                    if (amount <= 0 || !pl.take(p.getUniqueId(), amount)) {
                        p.sendMessage("§cYou do not have enough Shards."); return true;
                    }
                    pl.give(target.getUniqueId(), amount);
                    p.sendMessage("§aPaid §f" + amount + " Shards §ato §f" + target.getName() + "§a.");
                    target.sendMessage("§aReceived §f" + amount + " Shards §afrom §f" + p.getName() + "§a.");
                    return true;
                }
                case "friends" -> {
                    if (a.length == 0) {
                        Set<UUID> fs = pl.friends.getOrDefault(p.getUniqueId(), Set.of());
                        p.sendMessage("§dFriends §7(" + fs.size() + "):");
                        for (UUID id : fs) {
                            OfflinePlayer op = Bukkit.getOfflinePlayer(id);
                            p.sendMessage("§7- §f" + op.getName());
                        }
                        return true;
                    }
                    String sub = a[0].toLowerCase(Locale.ROOT);
                    if (sub.equals("add") && a.length >= 2) {
                        Player target = pl.findPlayer(a[1]);
                        if (target == null) { p.sendMessage("§cPlayer not found."); return true; }
                        if (target == p) { p.sendMessage("§cYou cannot add yourself."); return true; }
                        pl.friends.computeIfAbsent(p.getUniqueId(), k -> new HashSet<>()).add(target.getUniqueId());
                        p.sendMessage("§aAdded §f" + target.getName() + " §ato your friends.");
                        return true;
                    }
                    if ((sub.equals("remove") || sub.equals("del")) && a.length >= 2) {
                        Player target = pl.findPlayer(a[1]);
                        UUID id = target != null ? target.getUniqueId() : Bukkit.getOfflinePlayer(a[1]).getUniqueId();
                        Set<UUID> fs = pl.friends.get(p.getUniqueId());
                        if (fs != null) fs.remove(id);
                        p.sendMessage("§aRemoved §f" + a[1] + " §afrom your friends.");
                        return true;
                    }
                    p.sendMessage("§d/friends §7| §d/friends add <player> §7| §d/friends remove <player>");
                    return true;
                }
                case "kit" -> {
                    p.sendMessage("§eKits are not configured in CryptvoiderShop yet.");
                    p.sendMessage("§7Use /shop to buy items.");
                    return true;
                }
                default -> { return false; }
            }
        }
    }


    static class MarketCommand implements CommandExecutor {
        final CryptvoiderShop pl; MarketCommand(CryptvoiderShop p){pl=p;}
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if(!(sender instanceof Player p)){sender.sendMessage("Players only.");return true;}
            if(label.equalsIgnoreCase("market")){pl.openMarket(p);return true;}
            if(args.length!=1){p.sendMessage("§cHold the item and use /sell <price>, or /market to browse listings.");return true;}
            long price; try{price=Long.parseLong(args[0]);}catch(Exception ex){p.sendMessage("§cPrice must be a number.");return true;}
            if(price<=0){p.sendMessage("§cPrice must be greater than zero.");return true;}
            ItemStack hand=p.getInventory().getItemInMainHand(); if(hand.getType().isAir()){p.sendMessage("§cHold the item you want to sell.");return true;}
            ItemStack listed=hand.clone(); p.getInventory().setItemInMainHand(null);
            pl.marketListings.add(new MarketListing(p.getUniqueId(),p.getName(),listed,price)); pl.saveMarketListings();
            p.sendMessage("§aListed §f"+listed.getAmount()+"x "+pretty(listed.getType())+" §afor §f"+price+" Shards§a. Use /market to view listings."); return true;
        }
    }

    static class TradeSession {
        final Player a, b;
        final Inventory invA, invB;
        boolean acceptedA = false, acceptedB = false, finishing = false;

        TradeSession(Player a, Player b) {
            this.a=a; this.b=b;
            this.invA=Bukkit.createInventory(null, 54, "§8Trade §7- §f"+b.getName());
            this.invB=Bukkit.createInventory(null, 54, "§8Trade §7- §f"+a.getName());
        }
        Player other(Player p) { return p.equals(a) ? b : a; }
        Inventory inv(Player p) { return p.equals(a) ? invA : invB; }
        void resetAccept() { acceptedA=false; acceptedB=false; }
        boolean bothAccepted(){ return acceptedA && acceptedB; }
    }

    static class TradeCommand implements CommandExecutor {
        final CryptvoiderShop pl;
        TradeCommand(CryptvoiderShop p){pl=p;}
        public boolean onCommand(CommandSender s, Command c, String label, String[] args){
            if(!(s instanceof Player p)){s.sendMessage("§cPlayers only.");return true;}
            if(args.length<1){p.sendMessage("§cUsage: /trade <player>");return true;}
            Player target=Bukkit.getPlayerExact(args[0]);
            if(target==null){p.sendMessage("§cPlayer not found.");return true;}
            if(target.equals(p)){p.sendMessage("§cYou cannot trade with yourself.");return true;}
            if(pl.trades.containsKey(p.getUniqueId()) || pl.trades.containsKey(target.getUniqueId())){
                p.sendMessage("§cYou or that player is already trading.");return true;
            }
            TradeSession t=new TradeSession(p,target);
            pl.trades.put(p.getUniqueId(),t); pl.trades.put(target.getUniqueId(),t);
            p.openInventory(t.invA); target.openInventory(t.invB);
            p.sendMessage("§aTrade started with §f"+target.getName()+"§a.");
            target.sendMessage("§aTrade started with §f"+p.getName()+"§a.");
            return true;
        }
    }

    void tradeClose(TradeSession t, Player who, boolean cancel){
        if(t.finishing)return;
        if(cancel){
            t.finishing=true;
            returnItems(t.invA,t.a); returnItems(t.invB,t.b);
            trades.remove(t.a.getUniqueId()); trades.remove(t.b.getUniqueId());
            if(t.a.isOnline()) t.a.closeInventory();
            if(t.b.isOnline()) t.b.closeInventory();
            t.a.sendMessage("§cTrade cancelled. Your items were returned.");
            t.b.sendMessage("§cTrade cancelled. Your items were returned.");
        }
    }

    void returnItems(Inventory inv, Player p){
        for(ItemStack item: inv.getContents()){
            if(item==null || item.getType()==Material.AIR)continue;
            Map<Integer,ItemStack> left=p.getInventory().addItem(item.clone());
            for(ItemStack x:left.values()) p.getWorld().dropItemNaturally(p.getLocation(),x);
        }
        inv.clear();
    }

    void completeTrade(TradeSession t){
        if(t.finishing)return;
        t.finishing=true;
        List<ItemStack> fromA=new ArrayList<>(), fromB=new ArrayList<>();
        for(ItemStack x:t.invA.getContents()) if(x!=null && x.getType()!=Material.AIR) fromA.add(x.clone());
        for(ItemStack x:t.invB.getContents()) if(x!=null && x.getType()!=Material.AIR) fromB.add(x.clone());
        t.invA.clear(); t.invB.clear();
        for(ItemStack x:fromB){
            Map<Integer,ItemStack> left=t.a.getInventory().addItem(x);
            for(ItemStack y:left.values())t.a.getWorld().dropItemNaturally(t.a.getLocation(),y);
        }
        for(ItemStack x:fromA){
            Map<Integer,ItemStack> left=t.b.getInventory().addItem(x);
            for(ItemStack y:left.values())t.b.getWorld().dropItemNaturally(t.b.getLocation(),y);
        }
        trades.remove(t.a.getUniqueId()); trades.remove(t.b.getUniqueId());
        t.a.closeInventory(); t.b.closeInventory();
        t.a.sendMessage("§aTrade completed!");
        t.b.sendMessage("§aTrade completed!");
    }

    @EventHandler
    public void tradeClick(InventoryClickEvent e){
        if(!(e.getWhoClicked() instanceof Player p))return;
        TradeSession t=trades.get(p.getUniqueId());
        if(t==null)return;
        Inventory top=e.getView().getTopInventory();
        if(top!=t.inv(p))return;
        int slot=e.getRawSlot();
        // Bottom-row control buttons.
        if(slot>=45 && slot<54){
            e.setCancelled(true);
            if(slot==49){
                if(p.equals(t.a))t.acceptedA=!t.acceptedA; else t.acceptedB=!t.acceptedB;
                if(t.bothAccepted()) completeTrade(t);
                else {
                    p.sendMessage("§aYou "+((p.equals(t.a)?t.acceptedA:t.acceptedB)?"accepted":"unaccepted")+" the trade.");
                }
            } else if(slot==53){
                tradeClose(t,p,true);
            }
            return;
        }
        // Reserve control area; all other top slots are normal trade slots.
        if(slot>=45)e.setCancelled(true);
        if(!e.isCancelled()){
            t.resetAccept();
        }
    }

    @EventHandler
    public void tradeDrag(InventoryDragEvent e){
        if(!(e.getWhoClicked() instanceof Player p))return;
        TradeSession t=trades.get(p.getUniqueId());
        if(t==null)return;
        for(int slot:e.getRawSlots()) if(slot>=45 && slot<54){e.setCancelled(true);return;}
        if(!e.isCancelled())t.resetAccept();
    }

    @EventHandler
    public void tradeQuit(PlayerQuitEvent e){
        UUID id=e.getPlayer().getUniqueId();
        TradeSession t=trades.get(id);
        if(t!=null)tradeClose(t,e.getPlayer(),true);
        plCleanup(id);
    }

    static class ShardsCommand implements CommandExecutor {
        final CryptvoiderShop pl; ShardsCommand(CryptvoiderShop p){pl=p;}
        public boolean onCommand(CommandSender s, Command c, String l, String[] a){
            if(a.length==0||a[0].equalsIgnoreCase("balance")){
                if(s instanceof Player p)s.sendMessage("§dYou have §f"+pl.balance(p.getUniqueId())+" §dShards.");
                return true;
            }
            if(!s.hasPermission("cryptvoidershop.admin")){s.sendMessage("§cNo permission.");return true;}
            if(a.length<3){s.sendMessage("§c/shards <give|take|set> <player> <amount>");return true;}
            Player p=Bukkit.getPlayerExact(a[1]); if(p==null){s.sendMessage("§cPlayer not found.");return true;}
            long n; try{n=Long.parseLong(a[2]);}catch(Exception ex){s.sendMessage("§cInvalid amount.");return true;}
            switch(a[0].toLowerCase()){
                case "give" -> pl.give(p.getUniqueId(),n);
                case "take" -> pl.setBalance(p.getUniqueId(),pl.balance(p.getUniqueId())-n);
                case "set" -> pl.setBalance(p.getUniqueId(),n);
                default -> {s.sendMessage("§cUnknown action.");return true;}
            }
            s.sendMessage("§aDone. §f"+p.getName()+"§a now has §f"+pl.balance(p.getUniqueId())+" §aShards.");
            return true;
        }
    }
}
